from django.apps import AppConfig


class AtmConfig(AppConfig):
    name = 'Atm'
